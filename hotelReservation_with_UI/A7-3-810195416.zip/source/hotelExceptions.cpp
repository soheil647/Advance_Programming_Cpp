#include "../header/hotelExceptions.hpp"

using namespace std;


Hotel_Exceptions::Hotel_Exceptions(const string& _error) {
    error = _error;
}

